<?php include '../view/header.php'; ?>
<main>
    <h1>Register Product</h1> 
    <br>
    
    Product ( <?php echo $productCode; ?> ) was registered succesfully

</main>
    <?php include '../view/footer.php'; ?>