<?php include '../view/header.php'; ?>
<main>
    <h1>Create incident</h1> 
    <br>
    
    this incident was added to our database
    
    <?php // echo $title; ?>
    <?php // echo $description; ?>
    <?php // echo $customerID; ?>
    <?php //echo $qeury; ?>

</main>
    <?php include '../view/footer.php'; ?>